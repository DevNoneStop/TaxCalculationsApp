
--Name : Leseo Gaompe
--Created date: 05/12/2023
--Purpose: This is a scrip to create a new Database and table for the employee, to save the calculated tax

--SQL Create Database

CREATE DATABASE dms_Employee;
GO
--use the newly created Database to create tables
USE [dms_Employee]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
--SQL Create Table

CREATE TABLE [dbo].[Employee](
	[EmployeeId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](max) NULL,
	[Income] [float] NOT NULL,
	[PostalCode] [nvarchar](max) NULL,
	[TaxCalculated] [float] NOT NULL,
	[CreatedDate] [datetime2](7) NULL,
 CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


